import InputGroup from './InputGroup'
import Addon from './Addon'

InputGroup.Addon = Addon

export default InputGroup
