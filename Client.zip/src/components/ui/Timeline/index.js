import TimeLine from './TimeLine'
import TimeLineItem from './TimeLineItem'

TimeLine.Item = TimeLineItem

export default TimeLine
