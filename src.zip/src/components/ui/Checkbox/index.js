import Checkbox from './Checkbox'
import Group from './Group'

Checkbox.Group = Group

export default Checkbox
