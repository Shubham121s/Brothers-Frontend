export const SUPER_ADMIN = 'super-admin'
export const ADMIN = 'admin'
export const SUB_ADMIN = 'sub-admin'
export const EXECUTIVE = 'executive'
