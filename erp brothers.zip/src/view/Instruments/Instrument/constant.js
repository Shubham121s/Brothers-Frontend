export const Locations = [
  { label: 'UNIT 1 CNC', value: 'UNIT 1 CNC' },
  { label: 'UNIT 2 CNC', value: 'UNIT 2 CNC' },
  { label: 'VMC & DRILLING', value: 'VMC & DRILLING' },
  { label: 'QUALITY ', value: 'QUALITY ' }
]

export const In_USE = [
  { label: 'YES', value: 'YES' },
  { label: 'NO', value: 'NO' },
  { label: 'SCRAP', value: 'SCRAP' }
]

export const frequencyType = [
  { label: 'YEAR', value: 'YEAR' },
  { label: 'MONTH', value: 'MONTH' }
]
