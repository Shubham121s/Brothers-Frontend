export const APP_NAME = "5TechG Lab LLP";
export const PERSIST_STORE_NAME = "user";
export const REDIRECT_URL_KEY = "redirectUrl";

export const SECRET_KEY = "0123456789abcdef0123456789abcdef";
