const appConfig = {
  // apiPrefix: "https://api-erp.brothers.net.in/api/",
  // apiPrefix: "https://3b54-103-16-30-68.ngrok-free.app/api/",
  apiPrefix: "http://localhost:5005/api/",
  // apiPrefix: "https://brothers-backend.onrender.com/api/",
  // apiPrefix: "https://brothersapi.vaishnaviprofile.com/api/",

  // apiPrefix: "https://mastererp.5techg.com/api/",
  //
  // apiPrefix: "https://api-casting.brothers.net.in/api/",
  authenticatedEntryPath: "/dashboard",
  unAuthenticatedEntryPath: "/sign-in",
  tourPath: "/",
  locale: "en",
  enableMock: true,
};

export default appConfig;
